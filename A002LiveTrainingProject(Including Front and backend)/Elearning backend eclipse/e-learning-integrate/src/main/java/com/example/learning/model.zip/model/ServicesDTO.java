package com.example.learning.model;



public interface ServicesDTO {

	Integer getServiceId();
	String getServiceName();
}