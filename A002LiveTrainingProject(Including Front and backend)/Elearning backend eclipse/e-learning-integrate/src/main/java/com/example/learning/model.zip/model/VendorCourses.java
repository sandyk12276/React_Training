package com.example.learning.model;



//The class for the projection

public interface VendorCourses {
	
	 Integer getCourseid();
	 Integer getUserid();
	 String getName();
	 Integer getOrderid(); 
	 Integer getPaymentNo();
	 Integer getServicesId();
	 Boolean getIsComplete();


}
