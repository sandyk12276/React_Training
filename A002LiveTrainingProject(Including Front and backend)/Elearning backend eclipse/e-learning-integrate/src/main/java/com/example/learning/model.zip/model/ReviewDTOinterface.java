package com.example.learning.model;



public interface ReviewDTOinterface {
	
		Integer getReviewId();
		Integer getUserId();
		Integer getCourseId();
		String getDescription();

	}

